


import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { loadCartFromStorage, addItem, removeItem } from '../../../store/cartSlice';
import { Card, CardContent, List, ListItem, ListItemText, Typography, Button, Box } from '@mui/material';

export default function Cart() {
  const { items, totalPrice, discount, isHydrated } = useSelector(state => state.cart);
  const dispatch = useDispatch();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true); 
    dispatch(loadCartFromStorage());
  }, [dispatch]);

  if (!isClient || !isHydrated) {
    return <Typography>Loading cart...</Typography>; 
  }

  const discountedPrice = totalPrice - (totalPrice * discount) / 100;

  return (
    <Box display="flex" flexDirection="column" alignItems="center" mt={4}>
      <Card sx={{ width: 800, p: 2 }}>
        <CardContent>
          <Typography variant="h5" gutterBottom>
            Shopping Cart
          </Typography>
          <List>
            {items.map((item, index) => (
              <ListItem key={index} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <ListItemText primary={`${item.name} `} secondary={`$${item.price}`} />
                <Typography variant="body2" color="textSecondary">Quantity: {item.quantity} </Typography> 
                <Box display="flex" gap={1}>
                  
                  <Button variant="contained" color="gray" size="small" onClick={() => dispatch(removeItem(item))}>
                    -
                  </Button>
                  <Button variant="contained" color="gray" size="small" onClick={() => dispatch(addItem(item))}>
                    +
                  </Button>
                </Box>
              </ListItem>
            ))}
          </List>
          <Typography variant="h6" mt={2}>
            Total: ${totalPrice.toFixed(2)}
          </Typography>
          
          {discount > 0 && (
            <Typography variant="h6" color="green">
              Discount Applied: {discount}% (-${(totalPrice * discount / 100).toFixed(2)})
            </Typography>
          )}
          <Typography variant="h5" mt={2}>
            Final Price: ${discountedPrice.toFixed(2)}
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
}

