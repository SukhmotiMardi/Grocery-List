import Wrapper from "@/layout/wrapper/wrapper";
import "@/styles/globals.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";


import '../styles/globals.css';
import { store } from "@/store/store";
import { Provider } from "react-redux";




const queryClient = new QueryClient();

export default function App({ Component, pageProps }) {
    return (
        <div>
           
            <QueryClientProvider client={queryClient}>

            <Provider store={store}>
                <Wrapper>
                    <Component {...pageProps} />
                   
                </Wrapper>
                </Provider>
            </QueryClientProvider>
           
        </div>
       
    );
}